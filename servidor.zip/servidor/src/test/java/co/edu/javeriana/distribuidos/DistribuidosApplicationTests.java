package co.edu.javeriana.distribuidos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistribuidosApplicationTests {

	@Test
	void contextLoads() {
	}

}
