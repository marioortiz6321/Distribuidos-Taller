package co.edu.javeriana.distribuidos.security.enums;

public enum RolNombre {
    ROLE_ADMIN, ROLE_USER
}
