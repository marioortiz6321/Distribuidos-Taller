package co.edu.javeriana.distribuidos.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Mensaje {
    private String mensaje;

}
